// Grade-Calculator
let grade = Number(prompt("Enter A Score Number...."));
if(grade>=90 && grade<=100)
{
    console.log(grade,"You Have A Grade");
}
if(grade>=80 && grade<=89)
{
    console.log(grade,"You Have B Grade");
}
if(grade>=70 && grade<=79)
{
    console.log(grade,"You Have C Grade");
}
if(grade>=60 && grade<=69)
{
    console.log(grade,"You Have D Grade");
}
if(grade>=33 && grade<=59)
{
    console.log(grade,"You Have F Grade");
}
