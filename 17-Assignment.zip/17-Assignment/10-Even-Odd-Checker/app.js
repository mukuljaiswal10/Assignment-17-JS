// Even-Odd-Checker : -

let num5 = Number(prompt("Enter A Number"))
if (num5 % 2 == 0) {
    console.log(num5, " Even No")
}
else {
    console.log(num5, " Odd No")
}